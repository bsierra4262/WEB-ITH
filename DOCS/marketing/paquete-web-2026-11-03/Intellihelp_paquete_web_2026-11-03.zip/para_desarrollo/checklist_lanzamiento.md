# Checklist de lanzamiento de la web nueva de Intellihelp

Marcá cada punto antes de cambiar la web vieja por la nueva. Lo ideal: publicar un martes o miércoles a la mañana (nunca viernes) y dejar el día libre para revisar.

## A. Antes de publicar (en el entorno de prueba)

- [ ] El entorno de prueba tiene `noindex` (meta robots o contraseña) para que Google no lo indexe. **Al publicar se saca.**
- [ ] Las 21 páginas de `paginas_titulos_metas_encabezados.csv` existen con su URL exacta (con barra final).
- [ ] Cada página tiene su `<title>` y su `<meta name="description">` tal cual el CSV. Ninguno repetido.
- [ ] Cada página tiene **un solo H1** (el del CSV) y los H2 en el orden del CSV.
- [ ] `<html lang="es-AR">`. Sin etiquetas `hreflang` (no hay versión en inglés).
- [ ] `<link rel="canonical" href="https://www.intellihelp.tech/...">` en cada página, apuntando a sí misma, con www y https.
- [ ] El JSON-LD de cada página está pegado (carpeta `schema/`) y valida sin errores en https://validator.schema.org y en https://search.google.com/test/rich-results
- [ ] Todos los `[COMPLETAR...]` del JSON-LD y de las preguntas frecuentes se reemplazaron por datos reales (logo, año de fundación, Google Maps, Crunchbase, horarios y SLA).
- [ ] Las preguntas frecuentes visibles son idénticas al JSON-LD (`preguntas_frecuentes_textos.md`).
- [ ] El servicio y la cobertura están en **texto** en la página (nada importante dentro de videos o imágenes).
- [ ] Todas las imágenes tienen `alt` descriptivo; los logos de clientes con el nombre del cliente.
- [ ] Velocidad (ver LEEME, paso 7): PageSpeed Insights en móvil con LCP menor a 2,5 s, CLS menor a 0,1 e INP menor a 200 ms en la home y en una página de servicio.
- [ ] Formulario probado: llega el mail y se dispara el evento `cf7_enviado` en el dataLayer (paso 6 del LEEME).
- [ ] Página 404 propia, en castellano, con enlaces a Servicios, Soluciones y Contacto, que responda código **404** (no 200).

## B. El día del lanzamiento

- [ ] **GTM-54S82VL3** en el `<head>` de TODAS las páginas (sitio en código y blog WordPress) y el bloque `<noscript>` justo después de `<body>` (`gtm_snippet.html`).
- [ ] **Sacado el código viejo de Universal Analytics UA-5510484-16** y cualquier `gtag.js` pegado a mano. Un solo contenedor por página.
- [ ] **/servicios/ es parte de la web nueva** (con GTM): se borró la mini web estática vieja (`/servicios/index.html`, `empresas.html`, `home.html` y sus archivos) y sus URLs redirigen con 301.
- [ ] Reglas 301 de `htaccess_redirecciones.txt` cargadas arriba de las reglas de WordPress.
- [ ] Probadas **una por una** las 45 redirecciones de `redirecciones_301.csv`: `curl -sI URL_VIEJA` tiene que dar `301` y `location:` con el destino, y el destino `200`. Un solo salto, sin cadenas.
- [ ] `http://intellihelp.tech`, `http://www.intellihelp.tech` y `https://intellihelp.tech` llegan a `https://www.intellihelp.tech/` en **un solo salto**.
- [ ] Se sacó el `noindex` del entorno de prueba. Ninguna página pública tiene `noindex`.
- [ ] `robots.txt` nuevo subido a la raíz (`https://www.intellihelp.tech/robots.txt`).
- [ ] `llms.txt` subido a la raíz (`https://www.intellihelp.tech/llms.txt`), responde 200 con `Content-Type: text/plain; charset=utf-8`.
- [ ] `sitemap.xml` subido con la fecha de lanzamiento en `<lastmod>`, y el sitemap del blog en `/blog/sitemap_index.xml` (Yoast o Rank Math).
- [ ] **Bots de IA sin bloqueo en Hostinger.** Hoy el CDN devuelve error 429 a GPTBot (medido el 31/10/2026). En el panel de Hostinger, en la sección de seguridad o CDN, desactivar el bloqueo de bots de IA. Prueba: `curl -s -o /dev/null -w "%{http_code}" -A "GPTBot/1.2" https://www.intellihelp.tech/` tiene que dar 200.
- [ ] Caché de página activa (LiteSpeed Cache en el blog, caché del CDN en el sitio en código).

## C. Search Console y Bing (mismo día)

- [ ] Propiedad de dominio `intellihelp.tech` verificada en Google Search Console por registro DNS TXT (cubre www, sin www y subdominios). Dar acceso de propietario a ccavezzali@gmail.com.
- [ ] Enviado `https://www.intellihelp.tech/sitemap.xml` y `https://www.intellihelp.tech/blog/sitemap_index.xml` en Search Console, sección Sitemaps.
- [ ] Inspección de URL y "Solicitar indexación" de la home, las 4 páginas de servicio, las 4 de soluciones, /clientes/, /quienes-somos/ y /contacto/.
- [ ] Bing Webmaster Tools: importar desde Search Console (alimenta a Copilot y a ChatGPT Search).

## D. Primera semana después

- [ ] Search Console, Indexación de páginas: sin errores 404 nuevos ni "Página con redirección" inesperada. Si aparece una URL vieja con 404, sumarle su 301.
- [ ] GA4 Tiempo real recibe `page_view` desde un navegador sin extensiones y llegan `generate_lead`, `whatsapp_click`, `phone_click` y `email_click` al probarlos.
- [ ] Perfil de Google de Intellihelp: el sitio web apunta a `https://www.intellihelp.tech/` y la categoría principal es de servicios IT (lo hace el equipo de marketing).
- [ ] Actualizar la URL en LinkedIn, Crunchbase, infobel y hotfrog con los mismos datos de contacto (lo hace el equipo de marketing).

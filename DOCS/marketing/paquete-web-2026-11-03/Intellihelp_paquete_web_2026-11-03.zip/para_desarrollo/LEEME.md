# LEEME · Paquete técnico de búsqueda para la web nueva de Intellihelp

**Para:** Brian y Nicolás (equipo que rehace la web) · **De:** dirección externa de marketing · **Fecha:** 02/11/2026

Este paquete deja la web nueva lista para aparecer en Google y para que ChatGPT, Gemini, Perplexity, Claude y los resúmenes con IA de Google entiendan quién es Intellihelp y la recomienden. Todo está listo para copiar y pegar. Seguí los pasos en orden; cada uno dice qué archivo usar y cómo probar que quedó bien.

Si algo no encaja con cómo están armando el sitio (por ejemplo, otra estructura de URLs), avisanos antes de cambiarlo: los archivos están conectados entre sí (URLs, sitemap, JSON-LD, llms.txt y redirecciones usan las mismas direcciones).

## Qué hay en esta carpeta

| Archivo | Para qué sirve | Paso |
|---|---|---|
| `llms.txt` | **Pieza principal.** Ficha de Intellihelp para los asistentes de IA. Va a la raíz del sitio el día del lanzamiento | 1 y 5 |
| `llms_web_actual.txt` | La misma ficha con las URLs de la web de hoy, para subir YA | 1 |
| `robots.txt` | Permisos para buscadores y bots de IA, con el sitemap declarado | 5 |
| `sitemap.xml` | Mapa del sitio en código con las 21 páginas | 5 |
| `paginas_titulos_metas_encabezados.csv` | Por página: URL, keyword, title, meta description, H1 y H2 | 2 y 3 |
| `schema/` | 21 archivos JSON-LD, uno por página (Organization, ProfessionalService, WebSite, Service, FAQPage, BreadcrumbList) | 4 |
| `preguntas_frecuentes_textos.md` | Texto visible de las preguntas frecuentes de cada servicio (igual al JSON-LD) | 4 |
| `enlaces_internos.md` | Menú, pie, migas de pan y enlaces dentro del contenido | 3 |
| `gtm_snippet.html` | Código de Google Tag Manager GTM-54S82VL3 (head y noscript) | 6 |
| `redirecciones_301.csv` y `htaccess_redirecciones.txt` | Mapa de URLs viejas a nuevas y las reglas listas para el .htaccess | 8 |
| `checklist_lanzamiento.md` | Lo que se revisa antes, durante y después de publicar | 9 |

---

## Paso 1 · Ya mismo, en la web actual (15 minutos)

No hace falta esperar a la web nueva para estas tres cosas:

1. **Subí `llms_web_actual.txt` a la raíz con el nombre `llms.txt`** (por el administrador de archivos de Hostinger, en `public_html/`). Prueba: abrir `https://www.intellihelp.tech/llms.txt` y ver el texto. El día del lanzamiento lo reemplazás por el `llms.txt` de esta carpeta.
2. **Desbloqueá a los bots de IA en Hostinger.** Hoy el CDN le devuelve error 429 a GPTBot, el rastreador de ChatGPT (medido el 14/10 y de nuevo el 31/10/2026). Está en el panel de Hostinger, en la parte de seguridad o CDN (opción de bloqueo de bots de IA o protección contra bots). Prueba en la terminal:
   `curl -s -o /dev/null -w "%{http_code}" -A "GPTBot/1.2" https://www.intellihelp.tech/` tiene que dar **200**.
3. **Medición en la web actual:** sacá el código viejo de Universal Analytics (`UA-5510484-16`) del head, pegá el bloque `<noscript>` de `gtm_snippet.html` justo después de `<body>`, y sumá el código de Tag Manager a la página `/servicios` (es HTML suelto, fuera de WordPress, y hoy no mide).

## Paso 2 · Estructura de URLs

Las URLs nuevas están en la primera columna del CSV. Reglas:

- Todo en minúscula, palabras separadas con guion, **con barra al final** (`/servicios/mesa-de-ayuda/`). Elegí una forma (con barra) y redirigí la otra con 301.
- Se **mantienen** las URLs que ya conocen Google y las IA: `/`, `/contacto/`, `/quienes-somos/`, `/clientes/` y `/soluciones/`. El panel de Google de la marca enlaza a `/contacto/`.
- `/servicios/` deja de ser la mini web estática y pasa a ser la página de servicios de la web nueva (paso 8).
- El blog vive en WordPress en **`/blog/`** (subcarpeta, mismo dominio). Los artículos con URL corta: `/blog/cuanto-cuesta-una-mesa-de-ayuda-tercerizada/`.

```
/
├── servicios/            mesa-de-ayuda/ · soporte-it-empresas/ · outsourcing-it/ · consultoria-it/
├── soluciones/           redes-y-cableado-estructurado/ · control-de-accesos/ · videovigilancia/ · infraestructura-y-cloud/
├── sectores/             sector-publico/ · seguros-y-bancos/ · salud-y-laboratorios/ · industria/
├── clientes/             (casos; cada caso puede tener su página /clientes/<nombre-del-caso>/)
├── quienes-somos/  ·  contacto/  ·  preguntas-frecuentes/  ·  trabaja-con-nosotros/
└── blog/                 (WordPress)
```

## Paso 3 · Títulos, metas y encabezados

Abrí `paginas_titulos_metas_encabezados.csv` (Excel o Google Sheets). Por cada página:

- `<title>`: copiá la columna **Title** tal cual (todos tienen 60 caracteres o menos).
- `<meta name="description" content="...">`: copiá la columna **Meta description** (155 o menos).
- **Un solo `<h1>`** por página, con el texto de la columna H1. El logo y el menú van sin H1.
- Los **H2** en el orden de la columna (separados por `|`). Debajo de cada H2 van párrafos de texto, listas o tablas.
- `<html lang="es-AR">`, `<link rel="canonical">` apuntando a la propia URL con https y www, y etiquetas Open Graph (`og:title`, `og:description`, `og:image`, `og:locale` = `es_AR`).
- Sin `hreflang`: la web sale solo en castellano.

**Dos reglas de contenido que hacen la diferencia para Google y para las IA:**

1. **Respuesta corta arriba.** El primer párrafo debajo del primer H2 de cada servicio contesta en 40 a 60 palabras qué es, para quién y dónde. Es el texto que las IA copian.
2. **Todo en texto.** Servicios, cobertura, modalidad y casos escritos en la página, no dentro de videos ni imágenes (las IA no leen los videos de la home actual).

Los enlaces internos (menú, pie, migas de pan y enlaces entre páginas) están en `enlaces_internos.md`.

## Paso 4 · Datos estructurados (JSON-LD)

Cada archivo de `schema/` corresponde a una página (el CSV dice cuál en la última columna). Se pega dentro del `<head>` así:

```html
<script type="application/ld+json">
  ...contenido completo del archivo...
</script>
```

- La **home** lleva `00_home_organizacion_sede_sitio.json`: la ficha de la empresa (Organization con CUIT, dirección, teléfono y redes), la sede (ProfessionalService, que es un tipo de LocalBusiness, con horarios) y el sitio.
- Las demás páginas llevan su archivo: WebPage + BreadcrumbList, más **Service** en servicios y soluciones, y **FAQPage** donde hay preguntas frecuentes. Todas apuntan a la empresa con `"@id": "https://www.intellihelp.tech/#organizacion"`, así que la home tiene que estar publicada con su JSON-LD.
- Las preguntas frecuentes **visibles** en la página tienen que ser idénticas a las del JSON-LD: copialas de `preguntas_frecuentes_textos.md`.
- **Reemplazá todos los `[COMPLETAR...]`** antes de publicar (logo, foto de la oficina, año de fundación, enlace al perfil de Google Maps, Crunchbase, horarios y tiempos de respuesta). Si un dato no está, borrá esa línea entera del JSON antes que dejar el corchete.
- En el **blog**, el plugin de SEO (Yoast o Rank Math) genera el schema `Article` de cada nota. Configurá en el plugin la organización "Intellihelp" con el mismo logo.
- Prueba: https://validator.schema.org y https://search.google.com/test/rich-results sin errores.

## Paso 5 · llms.txt, robots.txt y sitemap

El día del lanzamiento, en la raíz del sitio (`https://www.intellihelp.tech/`):

1. **`llms.txt`** (el de esta carpeta, no el de la web actual). Tiene que responder 200 en `https://www.intellihelp.tech/llms.txt` como texto plano (`Content-Type: text/plain; charset=utf-8`). Si cambia una URL o un servicio, se actualiza este archivo.
2. **`robots.txt`**: deja todo abierto a buscadores y permite de forma explícita a GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-SearchBot, Claude-User, PerplexityBot, Perplexity-User, Google-Extended, Applebot-Extended, Bingbot y otros. Declara los dos sitemaps.
3. **`sitemap.xml`**: reemplazá `[FECHA-DE-LANZAMIENTO-AAAA-MM-DD]` por la fecha real (ej. `2026-11-18`). Si el sitio en código genera el sitemap solo, usá esta lista como control: tienen que estar las 21 URLs y ninguna redirigida ni con 404. El blog tiene su propio sitemap del plugin en `/blog/sitemap_index.xml`.
4. **Envío:** en Google Search Console (propiedad de dominio verificada por DNS) y en Bing Webmaster Tools, sección Sitemaps, enviá las dos direcciones. El detalle está en el checklist, parte C.

## Paso 6 · Medición (Tag Manager)

La medición ya está armada en Tag Manager (contenedor **GTM-54S82VL3**, que manda a GA4 `G-FN2F3JWFEL` y a Microsoft Clarity). La web solo tiene que:

1. Tener el código de `gtm_snippet.html` en **todas** las páginas: el script en el `<head>` y el `<noscript>` justo después de `<body>`. Vale para el sitio en código y para el blog WordPress.
2. **Sin UA-5510484-16** y sin ningún otro código de Google pegado a mano.
3. **Avisar cuando un formulario se envía bien.** Tag Manager hoy escucha el formulario de Contact Form 7. Si el formulario del sitio en código es otro, al confirmar el envío (después de que el servidor responde OK) agregá:

```js
window.dataLayer = window.dataLayer || [];
window.dataLayer.push({ event: 'cf7_enviado', cf7_form_id: 'contacto-' + location.pathname });
```

   Con eso el evento `generate_lead` sigue funcionando sin tocar Tag Manager.
4. WhatsApp como enlace `https://wa.me/5491150274827...`, teléfono como `tel:+541177006868` y mail como `mailto:info@intellihelp.tech`: Tag Manager ya mide esos clics.

## Paso 7 · Velocidad (Core Web Vitals)

La home actual pesa 11 MB y tarda 7,6 s en mostrar su contenido principal en móvil (Lighthouse, 14/10/2026). Objetivos para la web nueva, medidos en https://pagespeed.web.dev en **móvil**:

| Métrica | Objetivo |
|---|---|
| LCP (lo principal visible) | menos de 2,5 s |
| INP (respuesta al tocar) | menos de 200 ms |
| CLS (saltos de diseño) | menos de 0,1 |
| Peso de la home | menos de 1,5 MB |
| Respuesta del servidor (TTFB) | menos de 0,8 s |

Cómo llegar:

- Imágenes en **WebP o AVIF**, con `width` y `height` declarados, `srcset` para móvil y `loading="lazy"` en todo lo que está debajo del primer pantallazo. La imagen principal de arriba con `fetchpriority="high"` y sin lazy.
- **Sin videos de fondo** en la home. Si se usa un video, que sea con clic para reproducir y con imagen de portada.
- Fuentes: máximo 2 familias, archivos `woff2` alojados en el propio sitio, `font-display: swap` y `preload` de la principal.
- Un solo botón de WhatsApp (sin plugins extra) y un solo formulario.
- CSS crítico en línea y el resto diferido; JavaScript con `defer`. Tag Manager carga async y no bloquea.
- Caché del CDN de Hostinger activa para el sitio en código y LiteSpeed Cache en el blog.
- Redirección `http` y sin `www` a `https://www.intellihelp.tech/` en **un solo salto** (hoy son dos).

## Paso 8 · Redirecciones 301 (para no perder lo que Google ya conoce)

- `redirecciones_301.csv` tiene las **45 URLs viejas** con su destino y las que se mantienen igual.
- `htaccess_redirecciones.txt` tiene las mismas reglas listas para pegar **arriba** de las reglas de WordPress en el `.htaccess` de la raíz (Hostinger usa LiteSpeed, compatible con Apache).
- Antes de borrar la mini web estática de `/servicios/` (index.html, empresas.html, home.html), cargá las reglas: esas URLs pasan a la página nueva de servicios.
- Las notas de 2018 y los avisos de empleo de 2022 quedan como están, en sus URLs actuales: no se migran ni se redirigen.
- Si Search Console tiene historial, pedinos la lista de URLs con impresiones de los últimos 16 meses y sumamos al mapa las que falten.

## Paso 9 · Lanzamiento

Seguí `checklist_lanzamiento.md` de punta a punta. Las partes A y B son del equipo de desarrollo; la C (Search Console y Bing) la pueden hacer ustedes o nosotros, con acceso de propietario a ccavezzali@gmail.com.

---

## Datos que tiene que confirmar Intellihelp antes de publicar

1. **Teléfono principal: CONFIRMADO por Claudio el 02/11.** Teléfono +54 11 7700-6868 y WhatsApp +54 9 11 5027-4827. El 011 15-3230-8355 que figura en algunos directorios no se usa: si aparece en algún perfil, se reemplaza por estos dos. El mismo dato tiene que figurar en la web, el JSON-LD, el llms.txt y el perfil de Google.
2. **Trayectoria: CONFIRMADO por Claudio el 02/11.** La frase oficial es "14 años de trayectoria" y el JSON-LD lleva foundingDate 2012. El "2010" de la historia en la web vieja no se usa. En 2027 la frase pasa a "15 años": conviene que la web la calcule sola desde 2012.
3. **Provincias con técnicos** (en el llms.txt figura "más de 10 provincias").
4. **Clientes nombrables: CONFIRMADO por Claudio el 02/11.** Se pueden nombrar en texto Senado de la Nación, ASI, AGIP, Nación Seguros, Medifé, Pfizer y Bagó (llms.txt y página de clientes).
5. **Mesa de ayuda: PARCIAL, confirmado por Claudio el 02/11.** Horario de lunes a viernes de 9 a 18 en las oficinas de Intellihelp; en outsourcing de mesa de ayuda el horario depende de la empresa a la que se asigna el equipo. Falta: tiempos de respuesta por prioridad y modelo de precio publicable.
6. **Horario de atención: CONFIRMADO por Claudio el 03/11.** Lunes a viernes de 9 a 18 (igual que el perfil de Google). Usarlo igual en la web, el JSON-LD (openingHours Mo-Fr 09:00-18:00) y el llms.txt.

Ante cualquier duda, escribinos por el grupo de WhatsApp del proyecto.

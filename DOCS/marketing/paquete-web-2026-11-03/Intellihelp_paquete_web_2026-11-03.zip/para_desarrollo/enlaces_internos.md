# Enlaces internos de la web nueva

Regla general: cada página importante tiene que poder alcanzarse en **3 clics o menos** desde la home, y cada página de servicio recibe enlaces desde la home, su hub, los sectores, los casos y los artículos del blog. Los enlaces van con texto descriptivo (la keyword o una variante), nunca "clic acá" ni "ver más".

## Menú principal (en todas las páginas)

Servicios (desplegable con las 4 páginas) · Soluciones (desplegable con las 4) · Sectores (desplegable con las 4) · Clientes · Quiénes somos · Blog · **Agendá una reunión** (botón, va a /contacto/)

## Pie (en todas las páginas)

- Los 8 servicios y soluciones con su nombre completo.
- Quiénes somos, Clientes, Preguntas frecuentes, Trabajá con nosotros, Contacto.
- Bloque de datos idéntico al JSON-LD: Intellihelp S.A., Av. Dorrego 1789, piso 6, of. 604, C1414CKM, CABA · +54 11 7700-6868 · info@intellihelp.tech · enlace a LinkedIn.
- Copyright con el año actual.

## Enlaces dentro del contenido

| Desde | Enlaza a | Texto del enlace (ejemplo) |
|---|---|---|
| Home, bloque de servicios | Las 4 páginas de /servicios/ y las 4 de /soluciones/ | "mesa de ayuda tercerizada", "soporte IT para empresas", "outsourcing IT", "cableado estructurado"... |
| Home, franja de logos | /clientes/ y las 4 páginas de /sectores/ | "casos en el sector público", "clientes de seguros y bancos" |
| Cada página de servicio | 1 caso relacionado en /clientes/, 1 o 2 servicios complementarios, /contacto/ | "mirá el caso de la mesa de ayuda 7x24", "sumá soporte en sitio" |
| Mesa de ayuda | Soporte IT para empresas, Outsourcing IT | "técnicos en sitio", "equipo dedicado" |
| Soporte IT | Mesa de ayuda, Redes y cableado | "mesa de ayuda con SLA", "red y cableado de la oficina" |
| Control de accesos | Videovigilancia (y al revés) | "integración con cámaras", "control de acceso integrado" |
| Redes y cableado | Infraestructura y cloud, Videovigilancia | "servidores y data center", "red para cámaras IP" |
| Cada página de sector | Los 2 o 3 servicios que más usa ese sector y sus casos | "mesa de ayuda para organismos" |
| Cada caso en /clientes/ | El servicio y el sector que corresponden | |
| Cada artículo del blog | Su página de servicio (enlace en el primer tercio del texto) y /contacto/ al final | |
| /preguntas-frecuentes/ | La página de servicio de cada respuesta | |

## Breadcrumbs (migas de pan)

Visibles arriba del H1 en todas las páginas salvo la home, con el mismo recorrido que el JSON-LD `BreadcrumbList` de cada página. Ejemplo: Inicio › Servicios › Mesa de ayuda.

## Llamados a la acción

- Botón principal en cada página: **Agendá una reunión** (va a /contacto/ o abre el formulario).
- Botón secundario: WhatsApp con mensaje precargado por página, por ejemplo `https://wa.me/5491150274827?text=Hola%2C%20quiero%20consultar%20por%20mesa%20de%20ayuda`.
- Teléfono como enlace `tel:+541177006868` y mail como `mailto:info@intellihelp.tech` (así se miden los clics).

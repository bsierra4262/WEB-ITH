# Preguntas frecuentes por página (texto visible)

El texto que se ve en la página tiene que ser IDÉNTICO al del JSON-LD de esa página. Donde dice [COMPLETAR], Intellihelp da el dato y se cambia en los dos lugares.

## https://www.intellihelp.tech/servicios/mesa-de-ayuda/

**¿Qué es una mesa de ayuda tercerizada?**
Es un equipo externo que atiende las consultas e incidentes de tecnología de tus usuarios por teléfono, mail, chat o portal, los registra en un sistema de tickets y los resuelve o deriva según niveles de soporte, con un tiempo de respuesta acordado por contrato.

**¿Cuál es la diferencia entre help desk y service desk?**
El help desk resuelve incidentes puntuales de los usuarios. El service desk suma la gestión de pedidos, cambios y el catálogo de servicios con buenas prácticas ITIL. Intellihelp ofrece las dos modalidades según el tamaño y la madurez de tu área de sistemas.

**¿Qué horario y tiempo de respuesta ofrecen?**
La mesa de ayuda atiende de lunes a viernes de 9 a 18 desde nuestras oficinas. En el servicio de outsourcing de mesa de ayuda, el horario de cobertura se adapta a la empresa a la que se asigna el equipo. [COMPLETAR por Intellihelp: tiempos de respuesta por prioridad que se pueden publicar].

**¿Atienden en CABA, AMBA y el interior?**
Sí. La mesa de ayuda opera de forma remota para todo el país y la atención en sitio se coordina en CABA, AMBA y en las provincias donde Intellihelp tiene técnicos [COMPLETAR: lista de provincias].

**¿Cómo se cotiza una mesa de ayuda?**
Se cotiza por cantidad de usuarios o puestos, horario de cobertura, niveles de soporte incluidos y necesidad de técnicos en sitio. [COMPLETAR: modelo de precio publicable, por ejemplo abono mensual por puesto o desde qué tamaño conviene].

## https://www.intellihelp.tech/servicios/soporte-it-empresas/

**¿Qué incluye el soporte IT para empresas?**
Incluye la atención de usuarios, el mantenimiento preventivo y correctivo de computadoras, impresoras, servidores y redes, la gestión de altas y bajas de equipos y el seguimiento de cada incidente hasta su cierre.

**¿El soporte es remoto o en sitio?**
Las dos cosas. La mayoría de los incidentes se resuelve en forma remota y, cuando hace falta, un técnico va a tu oficina o planta. También se puede asignar un técnico dedicado de forma permanente.

**¿Trabajan con abono mensual o por demanda?**
Intellihelp trabaja con abono mensual para servicio continuo y también cotiza trabajos por demanda. [COMPLETAR: qué incluye el abono y desde qué cantidad de equipos conviene].

**¿Pueden dar soporte a sucursales en el interior?**
Sí. Coordinamos desde CABA a técnicos en las provincias donde operamos, con un solo responsable y un solo sistema de tickets para todas tus sedes.

## https://www.intellihelp.tech/servicios/outsourcing-it/

**¿Qué es el outsourcing IT?**
Es delegar en una empresa especializada la operación de una parte o de toda el área de tecnología: personas, procesos y herramientas, con objetivos y niveles de servicio acordados.

**¿Qué diferencia hay entre outsourcing IT y staff augmentation?**
En el outsourcing IT el proveedor gestiona el servicio y responde por el resultado. En staff augmentation se suman perfiles a tu equipo y tu empresa dirige el trabajo. Intellihelp ofrece las dos modalidades y la búsqueda de perfiles IT.

**¿Cuándo conviene tercerizar el área de sistemas?**
Conviene cuando la operación diaria consume al equipo interno, cuando hay picos de demanda o sedes en distintas provincias, o cuando se busca previsibilidad de costos con un contrato de servicio.

**¿Qué pasa al terminar el contrato?**
[COMPLETAR por Intellihelp: cómo se hace la transición, entrega de documentación, accesos y base de conocimiento].

## https://www.intellihelp.tech/servicios/consultoria-it/

**¿Qué hace una consultoría IT?**
Releva la infraestructura, los servicios y los procesos de tecnología de tu empresa, identifica riesgos y prioridades y deja un plan de mejora con etapas, costos y responsables.

**¿Trabajan con buenas prácticas ITIL?**
Sí. Los procesos de mesa de ayuda, gestión de incidentes, cambios y catálogo de servicios se diseñan sobre buenas prácticas ITIL, adaptadas al tamaño de cada organización.

**¿La consultoría incluye la implementación?**
Puede incluirla. El mismo equipo que hace el diagnóstico puede implementar las mejoras y dar soporte después.

## https://www.intellihelp.tech/soluciones/redes-y-cableado-estructurado/

**¿Qué es el cableado estructurado?**
Es el sistema ordenado de cables, conectores, racks y patcheras que lleva datos, voz y video por un edificio siguiendo normas internacionales, para que la red sea confiable, fácil de mantener y ampliable.

**¿Qué normas siguen y cómo se certifica?**
Las instalaciones siguen normas ANSI/TIA-568 e ISO/IEC 11801, y cada punto se certifica con equipo de medición al terminar la obra. [COMPLETAR: equipo certificador y entrega de informe].

**¿Hacen fibra óptica además de cobre?**
Sí. Instalamos cableado de cobre categoría 6 y 6A, fibra óptica entre edificios y pisos, racks, redes wifi y equipamiento activo.

**¿Trabajan en obra nueva y en mudanzas?**
Sí: obra nueva, ampliaciones, mudanzas de oficinas y reordenamiento de racks existentes.

## https://www.intellihelp.tech/soluciones/control-de-accesos/

**¿Qué tipos de control de acceso hay para empresas?**
Los más usados son lectores de tarjeta o llavero, biométricos de huella, reconocimiento facial y molinetes para ingresos con mucho tránsito. Se combinan según el nivel de seguridad de cada área.

**¿El control de acceso puede registrar la asistencia del personal?**
Sí. El mismo sistema puede registrar entradas y salidas y exportar la información para liquidación de horas o reportes de asistencia.

**¿Se integra con las cámaras de seguridad?**
Sí. El control de acceso puede vincularse con el sistema de videovigilancia para asociar cada evento de ingreso con la imagen de la cámara.

**¿Hacen el mantenimiento?**
Sí. Ofrecemos mantenimiento preventivo y correctivo de lectores, molinetes, cerraduras y software.

## https://www.intellihelp.tech/soluciones/videovigilancia/

**¿Qué incluye un sistema de videovigilancia para empresas?**
Incluye cámaras IP, grabadores o servidores de video, almacenamiento, la red que los conecta y el software de visualización, con acceso desde el puesto de monitoreo o el celular.

**¿Cómo se define cuántas cámaras hacen falta?**
Se releva el lugar, se definen las zonas a cubrir y el nivel de detalle necesario en cada una (ver, reconocer o identificar) y con eso se elige la cantidad, el tipo de cámara y los días de grabación.

**¿Qué es la analítica de video?**
Es el análisis automático de las imágenes para detectar eventos, como cruce de línea, intrusión en horario no permitido o conteo de personas, y generar alertas.

**¿Hacen mantenimiento de sistemas instalados por otros?**
[COMPLETAR por Intellihelp: sí o no y condiciones].

## https://www.intellihelp.tech/soluciones/infraestructura-y-cloud/

**¿Qué es la infraestructura IT?**
Es el conjunto de servidores, almacenamiento, redes, data center y servicios en la nube sobre los que funcionan las aplicaciones y los datos de una empresa.

**¿Cómo se planifica una migración a la nube?**
Se inventarían las aplicaciones, se define qué conviene llevar a la nube y qué conviene mantener en servidores propios, se estiman costos y se migra por etapas con pruebas y plan de vuelta atrás.

**¿Pueden administrar la infraestructura después?**
Sí. El mismo equipo puede monitorear, mantener y dar soporte a la infraestructura implementada.

